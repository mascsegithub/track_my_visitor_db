-- phpMyAdmin SQL Dump
-- version 4.0.10.18
-- https://www.phpmyadmin.net
--
-- Host: localhost:3306
-- Generation Time: Feb 18, 2017 at 01:05 AM
-- Server version: 5.5.54-cll
-- PHP Version: 5.6.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `softtest_trackmyvisitor_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `t_authorise_visitor`
--

CREATE TABLE IF NOT EXISTS `t_authorise_visitor` (
  `SpecialVisitorId` bigint(20) NOT NULL AUTO_INCREMENT,
  `SpecialVisitorName` varchar(100) NOT NULL,
  `SpecialVisitorCompany` varchar(100) NOT NULL,
  `EmailAddress` varchar(100) NOT NULL,
  `Phone` varchar(50) NOT NULL,
  `EmployeeId` int(11) NOT NULL,
  `AppointmentDate` date NOT NULL,
  `QRAttachment` varchar(225) DEFAULT NULL,
  `EventId` int(11) NOT NULL,
  `VisitorImage` varchar(225) DEFAULT NULL,
  `VisitorTypeId` tinyint(2) NOT NULL,
  PRIMARY KEY (`SpecialVisitorId`),
  KEY `FK_AuthorizeVisitor_Employee` (`EmployeeId`),
  KEY `FK_AuthorizeVisitor_Event` (`EventId`),
  KEY `FK_AuthorizeVisitor_VisitorType` (`VisitorTypeId`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=15 ;

--
-- Dumping data for table `t_authorise_visitor`
--

INSERT INTO `t_authorise_visitor` (`SpecialVisitorId`, `SpecialVisitorName`, `SpecialVisitorCompany`, `EmailAddress`, `Phone`, `EmployeeId`, `AppointmentDate`, `QRAttachment`, `EventId`, `VisitorImage`, `VisitorTypeId`) VALUES
(11, 'Anwar Hossain', 'BNMPC', 'ihtarif@gmail.com', '01721624499', 79, '2016-10-19', '11_79_1476089962.png', 14, '80_nazim_mahmud.jpg', 3),
(12, 'test', 'test company', 'test@test.com', '123456', 128, '2016-10-18', '12_86_1476092384.png', 14, '13089982_1119150064804150_538587357_n.jpg', 1),
(13, 'Anwar Hossain', 'BNMPC', 'anwarcs36@gmail.com', '01721624499', 128, '2016-10-31', '13_121_1476342037.png', 24, 'softworks.jpg', 51),
(14, 'Anwar Hossain', 'NESM', 'anwarcs36@yahoo.com', '01721624499', 121, '2016-10-31', '14_121_1476592047.png', 26, NULL, 50);

-- --------------------------------------------------------

--
-- Table structure for table `t_company`
--

CREATE TABLE IF NOT EXISTS `t_company` (
  `CompanyId` int(11) NOT NULL AUTO_INCREMENT,
  `CompanyName` varchar(100) DEFAULT NULL,
  `api_key` varchar(100) NOT NULL,
  `CompanyImage` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`CompanyId`),
  UNIQUE KEY `CompanyName` (`CompanyName`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=185 ;

--
-- Dumping data for table `t_company`
--

INSERT INTO `t_company` (`CompanyId`, `CompanyName`, `api_key`, `CompanyImage`) VALUES
(112, 'Softworks123', '8c13e3f9fa542d9f46b3c4146cbead93', 'images.jpg'),
(156, 'uTech', 'a44245b615bc4a489d03c35dfb9de604', 'com.gif'),
(158, 'Simpro', '8591e00c4e7f3d2c1cdf94080c6db90a', NULL),
(159, 'hdhdj', '3b1f1b773236d829164fbfa21ef940c3', NULL),
(164, 'Softworks Ltd.', 'ecfd978aaf543f1c08ba693c1eb057d9', 'unnamed.png'),
(167, 'AMARCOMPANY2', '0fa8f8e8b417fc4a74cfdcc5aa19fb57', NULL),
(168, 'S Special', '5d04ccd1f086d4ae32195658b95b668c', NULL),
(169, 'DhakaIT Bd', '09f61a4467d0ad720c5a3d1089118b75', 'index.png'),
(173, 'SW', 'c97b32e0ed44b19e93f429a28305e261', 'Intel_swoosh_logo_300x198.jpg'),
(184, 'Niceit', '9ede6dce9d92f023088ce5772c8c89ae', 'index.png');

-- --------------------------------------------------------

--
-- Table structure for table `t_division`
--

CREATE TABLE IF NOT EXISTS `t_division` (
  `DivisionId` tinyint(4) NOT NULL AUTO_INCREMENT,
  `DivisionName` varchar(100) DEFAULT NULL,
  `SiteId` int(11) DEFAULT NULL,
  PRIMARY KEY (`DivisionId`),
  KEY `FK_Division_Site` (`SiteId`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=35 ;

--
-- Dumping data for table `t_division`
--

INSERT INTO `t_division` (`DivisionId`, `DivisionName`, `SiteId`) VALUES
(1, 'Software Development', 122),
(2, 'Administration', 122),
(9, 'Accounts', 122),
(14, 'Administration', 116),
(16, 'Administration', 118),
(20, 'Administration', 122),
(23, 'Administration', 125),
(24, 'Administration', 127),
(25, 'Administration', 127),
(26, 'Administration', 127),
(27, 'Administration', 127),
(28, 'Procurements', 122),
(29, 'Costing Deparment', 122),
(30, 'Human Resource', 122),
(31, 'Finance', 122),
(32, 'Software Support', 122),
(33, 'Research and Development', 122),
(34, 'Odit', 122);

-- --------------------------------------------------------

--
-- Table structure for table `t_employee`
--

CREATE TABLE IF NOT EXISTS `t_employee` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `FirstName` varchar(25) NOT NULL,
  `LastName` varchar(25) NOT NULL,
  `UserName` varchar(100) NOT NULL,
  `FullName` varchar(100) DEFAULT NULL,
  `EmailAddress` varchar(100) NOT NULL,
  `JobTitle` varchar(100) DEFAULT NULL,
  `MobileNo` varchar(50) DEFAULT NULL,
  `DeskPhoneNo` varchar(50) DEFAULT NULL,
  `Password` varchar(100) NOT NULL,
  `Block` tinyint(1) DEFAULT '0',
  `Activation` tinyint(1) DEFAULT '1',
  `IsHost` tinyint(1) DEFAULT '1' COMMENT 'Pin to ''Host selection'' screen',
  `IsSiteAdmin` tinyint(1) DEFAULT '0',
  `IsCompanyAdmin` tinyint(1) DEFAULT '0',
  `SendEmail` tinyint(1) DEFAULT '1' COMMENT 'Send ''Welcome'' email',
  `CountryName` varchar(50) DEFAULT NULL,
  `CompanyId` int(11) DEFAULT NULL,
  `SiteId` int(11) DEFAULT NULL COMMENT 'Can be visited at',
  `DivisionId` tinyint(3) DEFAULT NULL,
  `RegisterDate` datetime DEFAULT NULL,
  `LastVisitDate` datetime DEFAULT NULL,
  `EmployeeImage` varchar(255) NOT NULL,
  PRIMARY KEY (`Id`),
  KEY `FK_Employee_Company` (`CompanyId`),
  KEY `FK_Employee_Division` (`DivisionId`),
  KEY `FK_Employee_Site` (`SiteId`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=142 ;

--
-- Dumping data for table `t_employee`
--

INSERT INTO `t_employee` (`Id`, `FirstName`, `LastName`, `UserName`, `FullName`, `EmailAddress`, `JobTitle`, `MobileNo`, `DeskPhoneNo`, `Password`, `Block`, `Activation`, `IsHost`, `IsSiteAdmin`, `IsCompanyAdmin`, `SendEmail`, `CountryName`, `CompanyId`, `SiteId`, `DivisionId`, `RegisterDate`, `LastVisitDate`, `EmployeeImage`) VALUES
(79, 'Nazim', 'Mahmud 456', 'Nazim', 'Nazim Mahmud 456', 'nazim1.ma@gmail.com', 'IT Officer ', '5555', '52555 888', '061e744a5b8b9b57b15266af05bbf68b', 0, 1, 1, 1, 1, 1, NULL, 112, 70, 1, NULL, NULL, 'images.jpg'),
(108, 'flasfj', 'ffaff', 'flasfj', 'flasfj ffaff', 'mehediwedevs@gmail.com', NULL, NULL, NULL, '91ec8d992540095dccbaa04a3e5ba55f', 0, 1, 1, 1, 1, 1, NULL, 156, 111, 9, NULL, NULL, ''),
(114, 'Anwar', 'Hossain', 'Anwar', 'Anwar Hossain', 's.anwar369@gmail.com', 'Executive', '', '', '202cb962ac59075b964b07152d234b70', 0, 1, 1, 1, 1, 1, NULL, 158, 116, 14, NULL, NULL, 'abrar_jaheen.jpg'),
(116, 'nazim', 'mahmud', 'nazim', 'nazim mahmud', 'nazim1.ma@yahoo.com', NULL, NULL, NULL, '061e744a5b8b9b57b15266af05bbf68b', 0, 1, 1, 1, 1, 1, NULL, 167, 118, 16, NULL, NULL, ''),
(121, 'Mahmudul', 'Islam', 'Mahmudul', 'Mahmudul Islam', 'mahmudiapps@gmail.com', 'IT Admin', '', '', '8e2036c4740bac0869663e1207a11560', 0, 1, 1, 1, 1, 1, NULL, 164, 122, 20, NULL, NULL, 'Mahmudul_Islam.jpg'),
(128, 'Imran', 'Hasan', 'Imran', 'Imran Hasan', 'hasantarif@yahoo.com', 'Test Job title', '01709270838', '123456', '', 0, 1, 1, 0, 0, 1, NULL, 112, 70, 2, NULL, NULL, ''),
(129, 'Anwar', 'Hossain', 'Anwar', 'Anwar Hossain', 'anwarcs36@yahoo.com', 'Manager', '01721624499', '', '', 0, 1, 1, 0, 0, 0, NULL, 164, 122, 20, NULL, NULL, 'anwar_05.jpg'),
(130, 'Abdus', 'Salam', 'Abdus', 'Abdus Salam', 'salam.niceit@gmail.com', NULL, '01924663948', NULL, '827ccb0eea8a706c4c34a16891f84e7b', 0, 1, 1, 1, 1, 1, NULL, 184, 127, 27, NULL, NULL, 'imas.jpg'),
(131, 'Abdus', 'Salam', 'Abdus', 'Abdus Salam', 'salam.pustcssse@gmail.com', 'IT Officer', '1924663948', '015489', '', 0, 1, 1, 0, 0, 1, NULL, 184, 127, 24, NULL, NULL, ''),
(132, 'Nazim', 'Mahmud', 'Nazim', 'Nazim Mahmud', 'nazimmahmud83@gmail.com', 'Programmer', '01915826995', '01915826995', '', 0, 1, 1, 0, 0, 1, NULL, 164, 122, 1, NULL, NULL, 'n.png'),
(133, 'Imran', 'Hasan', 'Imran', 'Imran Hasan', 'ihtarif@gmail.com', 'Sr. Programmer', '01709270838', '123456', '', 0, 1, 1, 0, 0, 1, NULL, 164, 122, 1, NULL, NULL, '101_nazim.jpg'),
(134, 'Md. Baharul', 'Islam', 'Md. Baharul', 'Md. Baharul Islam', 'rubel28.diit@gmail.com', 'Jr. Programmer', '01718488334', '', '', 0, 1, 1, 0, 0, 1, NULL, 164, 122, 1, NULL, NULL, 'Capture.png'),
(135, 'Sujit Kumar', 'Sen', 'Sujit Kumar', 'Sujit Kumar Sen', 'sujit2j8@gmail.com', 'Sr. Programmer', '01736888310', '01736888310', '', 0, 1, 1, 0, 0, 1, NULL, 164, 122, 1, NULL, NULL, 'Image.JPG'),
(136, 'Mahbub', 'Alam', 'Mahbub', 'Mahbub Alam', 'mahbub86dc@yahoo.com', 'Jr. Programmer', '01620540104', '', '', 0, 1, 1, 0, 0, 1, NULL, 164, 122, 1, NULL, NULL, 'IMG_20131003_204248.jpg'),
(137, 'Rubel', 'Mea', 'Rubel', 'Rubel Mea', 'rubel714@yahoo.com', 'Sr. Programmer', '01921232956', '', '', 0, 1, 1, 0, 0, 1, NULL, 164, 122, 1, NULL, NULL, 'rubel.jpg'),
(138, 'Abdus', 'Salam', 'Abdus', 'Abdus Salam', 'salam.softworks@gmail.com', 'Jr. Programmer', '01924663948', '', '', 0, 1, 1, 0, 0, 1, NULL, 164, 122, 1, NULL, NULL, '80_abdus_salam.jpg'),
(139, 'Hasan', 'Mahmud', 'Hasan', 'Hasan Mahmud', 'hmahmud70@gmail.com', 'EXECUTIVE DIRECTOR', '01819295651', '', '', 0, 1, 1, 0, 0, 0, NULL, 164, 122, 20, NULL, NULL, 'Hasan_Mahmud.jpg'),
(140, 'Md. Elias', 'Miah', 'Md. Elias', 'Md. Elias Miah', 'eliasparvez@yahoo.com', 'Support Mamager', '01682191200', '', '', 0, 1, 1, 0, 0, 1, NULL, 164, 122, 32, NULL, NULL, '17022012.jpg'),
(141, 'Md. Elias', 'Miah', 'Md. Elias', 'Md. Elias Miah', 'eliasparvez.g@gmail.com', 'Manager', '01682191200', '', '', 0, 1, 1, 0, 0, 1, NULL, 164, 122, 32, NULL, NULL, '');

-- --------------------------------------------------------

--
-- Table structure for table `t_event`
--

CREATE TABLE IF NOT EXISTS `t_event` (
  `EventId` int(11) NOT NULL AUTO_INCREMENT,
  `EventName` varchar(300) NOT NULL,
  `CompanyId` int(11) NOT NULL,
  PRIMARY KEY (`EventId`),
  KEY `FK_Event_Company` (`CompanyId`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=30 ;

--
-- Dumping data for table `t_event`
--

INSERT INTO `t_event` (`EventId`, `EventName`, `CompanyId`) VALUES
(13, 'Event 1', 112),
(14, 'Event 3', 112),
(15, 'Event 4', 112),
(20, 'Event 5', 112),
(23, 'Eevent 1', 164),
(24, 'Event 2', 164),
(26, 'Eevent 4', 164),
(29, 'Event1', 184);

-- --------------------------------------------------------

--
-- Table structure for table `t_site`
--

CREATE TABLE IF NOT EXISTS `t_site` (
  `SiteId` int(11) NOT NULL AUTO_INCREMENT,
  `SiteName` varchar(100) NOT NULL,
  `LangCode` varchar(20) DEFAULT 'en-GB',
  `LangTitle` varchar(50) DEFAULT 'English',
  `TimeZone` varchar(100) DEFAULT NULL,
  `StreetAddress` text,
  `EmergencyContact` varchar(50) DEFAULT NULL,
  `SystemAssistantContct` varchar(50) DEFAULT NULL,
  `SiteLogo` varchar(150) DEFAULT NULL,
  `CompanyId` int(11) DEFAULT NULL,
  PRIMARY KEY (`SiteId`),
  KEY `FK_Site_Company` (`CompanyId`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=132 ;

--
-- Dumping data for table `t_site`
--

INSERT INTO `t_site` (`SiteId`, `SiteName`, `LangCode`, `LangTitle`, `TimeZone`, `StreetAddress`, `EmergencyContact`, `SystemAssistantContct`, `SiteLogo`, `CompanyId`) VALUES
(70, 'Head Office', 'en-GB', 'English', 'Dhaka', 'Dhaka', '01924669488', '22549996', NULL, 112),
(111, 'Head Office', 'en-GB', 'English', NULL, NULL, NULL, NULL, NULL, 156),
(116, 'Head Office', 'en-GB', 'English', NULL, NULL, NULL, NULL, NULL, 158),
(118, 'Head Office', 'en-GB', 'English', NULL, NULL, NULL, NULL, NULL, 159),
(122, 'Head Office', 'en-GB', 'English', NULL, NULL, NULL, NULL, NULL, 164),
(125, 'Head Office', 'en-GB', 'English', NULL, NULL, NULL, NULL, NULL, 167),
(127, 'Head Office', 'en-GB', 'English', '5544', 'Dhaka  ', '01924669488', '022549996', NULL, 184),
(128, 'Head Office2', 'en-GB', 'English', 'Dhaka', 'Dhaka', '01924669488', '22549996', NULL, 112),
(129, 'ABCSS', 'en-GB', 'English', 'Dhaka', 'Dhaka', '01924669488', '22549996', NULL, 184),
(131, 'ST', '', '', '', '', '01924669488', '', NULL, 184);

-- --------------------------------------------------------

--
-- Table structure for table `t_visitor`
--

CREATE TABLE IF NOT EXISTS `t_visitor` (
  `VisitorId` bigint(20) NOT NULL AUTO_INCREMENT,
  `VisitorName` varchar(100) NOT NULL,
  `VisitorCompany` varchar(100) NOT NULL,
  `VisitorTypeId` tinyint(2) DEFAULT NULL,
  `EmployeeId` int(11) NOT NULL,
  `SignInTime` datetime NOT NULL,
  `SignOutTime` datetime NOT NULL,
  `date` date NOT NULL,
  `Phone` varchar(50) NOT NULL,
  `EmailAddress` varchar(100) NOT NULL,
  `EstDuration` varchar(40) NOT NULL,
  `ImagePath` varchar(255) NOT NULL,
  PRIMARY KEY (`VisitorId`),
  KEY `FK_Visitor_VisitorType` (`VisitorTypeId`),
  KEY `FK_Visitor_Employee` (`EmployeeId`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=19 ;

--
-- Dumping data for table `t_visitor`
--

INSERT INTO `t_visitor` (`VisitorId`, `VisitorName`, `VisitorCompany`, `VisitorTypeId`, `EmployeeId`, `SignInTime`, `SignOutTime`, `date`, `Phone`, `EmailAddress`, `EstDuration`, `ImagePath`) VALUES
(1, 'Anwar Hossain', 'Gamma Comunication', 1, 129, '2016-10-16 11:09:09', '0000-00-00 00:00:00', '2016-10-16', '', '', '', '129-anwar-hossain.jpg'),
(2, 'Sreyan', 'Softtech', 2, 135, '2016-10-16 12:14:24', '0000-00-00 00:00:00', '2016-10-16', '', '', '', '135-sreyan.jpg'),
(3, 'Tt', 'Tt', 1, 134, '2016-10-16 17:11:28', '0000-00-00 00:00:00', '2016-10-16', '', '', '', '134-tt.jpg'),
(4, 'Sujit', 'Sen', 3, 139, '2016-10-16 17:15:28', '0000-00-00 00:00:00', '2016-10-16', '', '', '', '139-sujit.jpg'),
(5, 'Sujit Kumar Sen', 'Azze Tech.', 1, 137, '2016-10-16 17:43:04', '0000-00-00 00:00:00', '2016-10-16', '', '', '', '137-sujit-kumar-sen.jpg'),
(6, 'Sujit', 'Sff', 1, 137, '2016-10-16 21:50:19', '0000-00-00 00:00:00', '2016-10-16', '', '', '', '137-sujit.jpg'),
(7, 'Tyu', 'Dryy', 1, 138, '2016-10-16 21:55:58', '0000-00-00 00:00:00', '2016-10-16', '', '', '', '138-tyu.jpg'),
(8, 'Sujit Kumar Sen', 'Softworks Ltd.', 1, 135, '2016-10-16 22:42:07', '0000-00-00 00:00:00', '2016-10-16', '', '', '', '135-sujit-kumar-sen.jpg'),
(9, 'Sujit ', 'Sss', 1, 135, '2016-10-16 22:48:30', '0000-00-00 00:00:00', '2016-10-16', '', '', '', '135-sujit-.jpg'),
(10, 'Arif', 'Student', 1, 135, '2016-10-16 22:54:19', '0000-00-00 00:00:00', '2016-10-16', '', '', '', '135-arif.jpg'),
(11, 'Suit Kumar Sen', 'ST Solutions LLC', 1, 129, '2016-10-17 00:00:58', '0000-00-00 00:00:00', '2016-10-17', '', '', '', '129-suit-kumar-sen.jpg'),
(12, 'Sujit Kumar Sen', 'Soft works Ltd.', 1, 135, '2016-10-17 10:50:38', '0000-00-00 00:00:00', '2016-10-17', '', '', '', '135-sujit-kumar-sen.jpg'),
(13, 'Arham', 'Robi', 3, 137, '2016-10-17 10:56:31', '0000-00-00 00:00:00', '2016-10-17', '', '', '', '137-arham.jpg'),
(14, 'Elias Parvez', 'Karnapara Dying', 1, 135, '2016-10-17 13:43:20', '0000-00-00 00:00:00', '2016-10-17', '', '', '', '135-elias-parvez.jpg'),
(15, 'Minoar Hossain', 'Grammen Phone', 2, 121, '2016-10-17 13:46:41', '0000-00-00 00:00:00', '2016-10-17', '', '', '', '121-minoar-hossain.jpg'),
(16, 'Tofail ', 'Rfl', 1, 136, '2016-10-17 14:11:12', '0000-00-00 00:00:00', '2016-10-17', '', '', '', '136-tofail-.jpg'),
(17, 'Anwar Hossain', 'BNMPC', 51, 121, '2016-10-17 14:14:56', '0000-00-00 00:00:00', '2016-10-17', '', '', '', '121-anwar-hossain.jpg'),
(18, 'Mahabubur ', 'Fm', 2, 129, '2016-10-17 14:17:31', '0000-00-00 00:00:00', '2016-10-17', '', '', '', '129-mahabubur-.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `t_visitortype`
--

CREATE TABLE IF NOT EXISTS `t_visitortype` (
  `VisitorTypeId` tinyint(2) NOT NULL AUTO_INCREMENT,
  `VisitorType` varchar(50) NOT NULL,
  `CompanyId` int(11) DEFAULT NULL,
  PRIMARY KEY (`VisitorTypeId`),
  KEY `FK_VisitorType_Company` (`CompanyId`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=73 ;

--
-- Dumping data for table `t_visitortype`
--

INSERT INTO `t_visitortype` (`VisitorTypeId`, `VisitorType`, `CompanyId`) VALUES
(1, 'Visitor', 112),
(2, 'Delivery', 112),
(3, 'Contractor', 112),
(25, 'Visitor', 156),
(26, 'Contractor', 156),
(27, 'Delivery', 156),
(31, 'Visitor', 158),
(32, 'Contractor', 158),
(33, 'Delivery', 158),
(34, 'Visitor', 159),
(35, 'Contractor', 159),
(36, 'Delivery', 159),
(49, 'Visitor', 164),
(50, 'Contractor', 164),
(51, 'Delivery', 164),
(58, 'Visitor', 167),
(59, 'Contractor', 167),
(60, 'Delivery', 167),
(61, 'Visitor', 168),
(62, 'Contractor', 168),
(63, 'Delivery', 168),
(64, 'Visitor', 169),
(65, 'Contractor', 169),
(66, 'Delivery', 169),
(67, 'Visitor', 173),
(68, 'Contractor', 173),
(69, 'Delivery', 173),
(70, 'Visitor', 184),
(71, 'Contractor', 184),
(72, 'Delivery', 184);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `t_authorise_visitor`
--
ALTER TABLE `t_authorise_visitor`
  ADD CONSTRAINT `FK_AuthorizeVisitor_Employee` FOREIGN KEY (`EmployeeId`) REFERENCES `t_employee` (`Id`),
  ADD CONSTRAINT `FK_AuthorizeVisitor_Event` FOREIGN KEY (`EventId`) REFERENCES `t_event` (`EventId`),
  ADD CONSTRAINT `FK_AuthorizeVisitor_VisitorType` FOREIGN KEY (`VisitorTypeId`) REFERENCES `t_visitortype` (`VisitorTypeId`);

--
-- Constraints for table `t_division`
--
ALTER TABLE `t_division`
  ADD CONSTRAINT `FK_Division_Site` FOREIGN KEY (`SiteId`) REFERENCES `t_site` (`SiteId`);

--
-- Constraints for table `t_employee`
--
ALTER TABLE `t_employee`
  ADD CONSTRAINT `FK_Employee_Company` FOREIGN KEY (`CompanyId`) REFERENCES `t_company` (`CompanyId`),
  ADD CONSTRAINT `FK_Employee_Division` FOREIGN KEY (`DivisionId`) REFERENCES `t_division` (`DivisionId`),
  ADD CONSTRAINT `FK_Employee_Site` FOREIGN KEY (`SiteId`) REFERENCES `t_site` (`SiteId`);

--
-- Constraints for table `t_event`
--
ALTER TABLE `t_event`
  ADD CONSTRAINT `FK_Event_Company` FOREIGN KEY (`CompanyId`) REFERENCES `t_company` (`CompanyId`);

--
-- Constraints for table `t_site`
--
ALTER TABLE `t_site`
  ADD CONSTRAINT `FK_Site_Company` FOREIGN KEY (`CompanyId`) REFERENCES `t_company` (`CompanyId`);

--
-- Constraints for table `t_visitor`
--
ALTER TABLE `t_visitor`
  ADD CONSTRAINT `FK_Visitor_Employee` FOREIGN KEY (`EmployeeId`) REFERENCES `t_employee` (`Id`),
  ADD CONSTRAINT `FK_Visitor_VisitorType` FOREIGN KEY (`VisitorTypeId`) REFERENCES `t_visitortype` (`VisitorTypeId`);

--
-- Constraints for table `t_visitortype`
--
ALTER TABLE `t_visitortype`
  ADD CONSTRAINT `FK_VisitorType_Company` FOREIGN KEY (`CompanyId`) REFERENCES `t_company` (`CompanyId`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
